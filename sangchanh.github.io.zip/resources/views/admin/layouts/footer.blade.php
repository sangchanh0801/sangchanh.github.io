<!-- jquery vendor -->
<script src="{{('/public/backend/js/lib/jquery.min.js')}}"></script>
<script src="{{('/public/backend/js/lib/jquery.nanoscroller.min.js')}}"></script>
<!-- nano scroller -->
<script src="{{('/public/backend/js/lib/menubar/sidebar.js')}}"></script>
<script src="{{('/public/backend/js/lib/preloader/pace.min.js')}}"></script>
<!-- sidebar -->

<script src="{{('/public/backend/js/lib/bootstrap.min.js')}}"></script>
<script src="{{('/public/backend/js/scripts.js')}}"></script>
<!-- bootstrap -->

<script src="{{('/public/backend/js/lib/calendar-2/moment.latest.min.js')}}"></script>
<script src="{{('/public/backend/js/lib/calendar-2/pignose.calendar.min.js')}}"></script>
<script src="{{('/public/backend/js/lib/calendar-2/pignose.init.js')}}"></script>


<script src="{{('/public/backend/js/lib/weather/jquery.simpleWeather.min.js')}}"></script>
<script src="{{('/public/backend/js/lib/weather/weather-init.js')}}"></script>
<script src="{{('/public/backend/js/lib/circle-progress/circle-progress.min.js')}}"></script>
<script src="{{('/public/backend/js/lib/circle-progress/circle-progress-init.js')}}"></script>
<script src="{{('/public/backend/js/lib/chartist/chartist.min.js')}}"></script>
<script src="{{('/public/backend/js/lib/sparklinechart/jquery.sparkline.min.js')}}"></script>
<script src="{{('/public/backend/js/lib/sparklinechart/sparkline.init.js')}}"></script>
<script src="{{('/public/backend/js/lib/owl-carousel/owl.carousel.min.js')}}"></script>
<script src="{{('/public/backend/js/lib/owl-carousel/owl.carousel-init.js')}}"></script>
<script src="{{asset('public/frontend/lib/easing/sweetalert.js')}}"></script>
<!-- scripit init-->
<script src="{{('/public/backend/assets/js/dashboard2.js')}}"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script src="http://cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.min.js"></script>
<script src="http://cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
@stack('scripts')




